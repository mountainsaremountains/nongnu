emacs-afternoon-theme
=====================

Dark color theme with a deep blue background
