# Sprites for Pacmacs #

## Modifying or adding sprites ##

Do not modify any \*.xpm or \*.json file directly. Use
[Aseprite][Aseprite] program to modify `src/*.ase` and then `$ make`
to regenerate sprites.

When you add new sprites, please automate their generation (see
`Makefile` for examples).

[Aseprite]: http://www.aseprite.org/
