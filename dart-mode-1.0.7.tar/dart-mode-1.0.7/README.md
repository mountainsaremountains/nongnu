
An Emacs major mode for editing Dart files. Provides basic syntax
highlighting and indentation.

Please see the [Wiki](https://github.com/bradyt/dart-mode/wiki) for
more information.
