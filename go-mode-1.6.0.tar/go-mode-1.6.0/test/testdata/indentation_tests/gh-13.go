package gh13

func init() {
	f :=
		print(1,
			2,
			3,
		)
}
