package multilinestring

func foo() string {
	s := `foo
bar
baz`

	return s
}
