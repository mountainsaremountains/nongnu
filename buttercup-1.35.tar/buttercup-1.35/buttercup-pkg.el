;; Generated package description from buttercup.el  -*- no-byte-compile: t -*-
(define-package "buttercup" "1.35" "Behavior-Driven Emacs Lisp Testing" '((emacs "24.4")) :commit "a1a86b027ffe030e1c78a9f43c50cd20a6fed19a" :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de")) :maintainer '("Ola Nilsson" . "ola.nilsson@gmail.com") :url "https://github.com/jorgenschaefer/emacs-buttercup")
