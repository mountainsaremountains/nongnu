#!/bin/sh

echo "Running autoreconf..."

autoreconf -i
