# bison-mode

Bison major-mode for Emacs.

## Changelog

### 0.3

Added support for jison mode.

jison-mode is started automatically for .jison files.

Functions are now properly namespaced.

### 0.2

Update for compatibility with modern Emacsen, and removed dependencies
on some ancient packages.

Many byte-compiler fixes.

Fixed a crash on indentation.

bison-mode is now started automatically for .y and .l files.

### 0.1

Initial release.
